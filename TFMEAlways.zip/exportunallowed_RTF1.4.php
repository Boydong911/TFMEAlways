<!DOCTYPE html>
<html>
<head>
	<title>ya</title>
</head>
<body>
	<?php
		date_default_timezone_set('Asia/Jakarta');
		$datetime = date('Y-m-d H:i:s');
		$date = date('Y-m-d');
		$time = date('H:i:s');

		$format_datetime = date("H:i:s / d-M-Y", strtotime($datetime));
	?>

	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Access Unallowed $date.xls");
	?>


	<?php include "connect.php"?>

	<center>
		<!-- <h1>Export Data Ke Excel Dengan PHP <br/> www.malasngoding.com</h1> -->
	</center>

	<table border="1">
		<tr>
            <th style="text-align: center">No.</th>
            <th style="text-align:center">ID</th>
            <th style="text-align:center">Jabatan</th>
            <th style="text-align:center">NIM</th>
            <th style="text-align:center">Nama</th>
            <th style="text-align:center">Kelas</th>
            <th style="text-align:center">Tanggal</th>
            <th style="text-align:center">Waktu</th>
            <th style="text-align:center">Ruangan</th>
        </tr>
		<?php 
		// koneksi database
		// $conn = mysqli_connect("localhost","root","","security");
 
		// menampilkan data pegawai
		$data = mysqli_query($conn,"SELECT * FROM authrecord WHERE ruangan='RTF1.4'");
		$no = 1;
		while($d = mysqli_fetch_array($data)){
		?>
		<tr>
			<td style="text-align: center"><?php echo $no++; ?></td>
			<td style="text-align: center"><?php echo $d['id']; ?></td>
			<td style="text-align: center"><?php echo $d['jabatan']; ?></td>
            <td style="text-align: center"><?php echo $d['nim']; ?></td>
			<td style="text-align: center"><?php echo $d['nama']; ?></td>
			<td style="text-align: center"><?php echo $d['prodi']; ?>-<?php echo $d['semester']; ?><?php echo $d['kelas']; ?>-<?php echo $d['pm']; ?></td>
			<td style="text-align: center"><?php echo $d['date']; ?></td>
			<td style="text-align: center"><?php echo $d['time']; ?></td>
			<td style="text-align: center"><?php echo $d['ruangan']; ?></td>
		</tr>
		<?php 
		}
		?>
	</table>
</body>
</html>