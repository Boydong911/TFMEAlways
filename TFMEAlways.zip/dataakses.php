<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Data Akses | TFME Always</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

    <!--Tabel CSS-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <!--Tabel JS-->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="assets/npm/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/rowreorder/1.2.8/js/dataTables.rowReorder.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

</head>

<style>
    .table{
        margin-top : 25px
    }
    .btnadd button{
    background-color: rgb(53, 163, 197);
    border: none;
    color: white;
    padding: 10px 15px;
    text-align: center;
    font-size: 15px;
    cursor: pointer;
    transition-property: background;
    box-shadow: 0 2px 7px rgba(0,0,0,0.3);
    margin-top: 15px;
    margin-bottom: 15px;
    margin-left: 15px;
    text-align: center;
    border-radius: 3px;
    font-weight: bold;
    }
    .btnadd button:hover{
    background-color: rgb(11, 69, 87);
    color: white;
    transition: 0.2s ease;
}
</style>
<body>
    <?php include "menu.php"; ?>
    <?php include "connect.php" ?>

    <?php
        // if != "door-member-add.php") {
        $result = mysqli_query($conn, "SELECT * FROM receivedata WHERE variabel='rfid'");
         $row = mysqli_fetch_array($result);
        $cek = $row["value"];

         if ($cek == '') mysqli_query($conn, "UPDATE receivedata SET value='-', status='-', mode='scan' WHERE variabel='rfid'");
         else            mysqli_query($conn, "UPDATE receivedata SET value='-', status='-', mode='scan' WHERE variabel='rfid'");
        // }
    ?>

    <?php $result = mysqli_query($conn,"SELECT * FROM doormember")?>

    <h1 style="margin-top : 100px ;margin-bottom : 10px; text-align: center; font-family:Tahoma; font-weight: bold; ">MEMBER</h1>

    <div class="btnadd">
        <a href="addmember.php"><button class="btn"> ADD MEMBER </button></a>
    </div>

    <div class="container-fluid">
     <table id="example" class="table table-dark table-stripped table-hover" >
	     <thead>
                <tr>
                    <th style="width:10px; text-align: center">No.</th>
                    <th style="text-align:center">ID</th>
                    <th style="text-align:center">Jabatan</th>
                    <th style="text-align:center">NIM</th>
                    <th style="text-align:center">Nama</th>
                    <th style="text-align:center">Kelas</th>
                    <th style="text-align:center">Jenis Kelamin</th>
                    <th style="text-align:center">Ruangan</th>
                    <th style="text-align:center">Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $no = 1; ?>
                <?php while($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td style="text-align:center"><?= $no; ?></td>
                    <td style="text-align:center"><?= $row["id"]; ?></td>
                    <td style="text-align:center"><?= $row["jabatan"]; ?></td>
                    <td style="text-align:center"><?= $row["nim"]; ?></td>
                    <td style="text-align:center"><?= $row["nama"]; ?></td>
                    <td style="text-align:center"><?= $row["prodi"]; ?>-<?= $row["semester"]; ?>-<?= $row["kelas"]; ?>-<?= $row["pm"]; ?> </td>
                    <td style="text-align:center"><?= $row["jeniskelamin"]; ?></td>
                    <td style="text-align:center">
                        <b class ="RTF14"> RTF1.4: <?= $row["RTF14"]; ?></b>
                        <br>
                        <b class ="CR"> CR: <?= $row["CR"]; ?></b>
                        <br>
                        <b class ="RTF61"> RTF6.1: <?= $row["RTF61"]; ?></b>
                        <br>
                        <b class ="RTF63"> RTF6.3: <?= $row["RTF63"]; ?></b>
                        <br>
                        <b class ="RTF61"> RTF6.4: <?= $row["RTF64"]; ?></b>
                        <br>
                        <b class ="RTFD4"> RTF D4: <?= $row["RTFD4"]; ?></b>
                        <br>
                    </td>
                    <td style="text-align:center">
                        <a class ="data-edit" href="dataedit.php?no=<?= $row["no"]; ?>" >Edit</a>
                        <a class = "data-delete" href="hapusdata.php?id=<?= $row["id"]; ?>">Hapus</a>
                    </td>
                </tr>
                <?php $no++; ?>
                <?php endwhile; ?>
            </tbody>
            <script>
                $(document).ready(function() {
                    $('#example').DataTable();
                } );
            </script>
            
        </table>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
</body>
</html>