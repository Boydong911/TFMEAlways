<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <title>POLIBATAM SECURITY SYSTEM</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    </head>
    
    <body>
        <?php
            include "connect.php";
            // Get ID from database
            $sql = mysqli_query($conn, "SELECT * FROM receivedata WHERE variabel='rfid'");
            $row = mysqli_fetch_array($sql);
            $ID = $row["value"];
            $STATUS = $row["status"];

            if ($ID == "-" || $STATUS == "already") {
                $url = $_SERVER['REQUEST_URI'];
                echo '<META HTTP-EQUIV="Refresh" Content="2"; URL="$url">';
                mysqli_query($conn, "UPDATE receivedata SET value='-', status='-' WHERE variabel='rfid'");
            }
            if($STATUS == "already"){
                $url = $_SERVER['REQUEST_URI'];
                echo '<META HTTP-EQUIV="Refresh" Content="1"; URL="$url">';
            }
            // if ($STATUS == "already") mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ('rfid','-','-')");
            // // Update database
            // if ($ID == "") mysqli_query($conn, "INSERT into receivedata (variabel, value, status) VALUES ('rfid', '$ID', '-')");
            // else mysqli_query($conn, "UPDATE receivedata SET value='$ID', status='-' WHERE variabel='rfid'");

            // if ($STATUS == "already") mysqli_query($conn, "UPDATE receivedata SET value='-', status='-' variabel='rfid'");
            // else                      mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ('rfid', '$ID', '')")
        ?>

        <div class="form"style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <span class="content-name" style="margin-right : 15px;">ID</span>
            <input type="text"  name="id" id="id"
                <?php 
                        if ($ID != "-" && $STATUS != "already")
                        { 
                            ?> value="<?php echo $ID; ?>" <?php 
                        } 
                        else if ($STATUS == "already") 
                        { 
                            ?> value="ID sudah digunakan" <?php 
                            
                        } 
                ?> required>
            <!-- <input type="text" name="nama" id='nama' autocomplete="off" required > -->
            <label for="id" class="form-label"></label>
        </div>
    </body>
</html>
