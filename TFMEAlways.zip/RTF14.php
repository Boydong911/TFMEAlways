<?php include "connect.php"?>

<?php
    date_default_timezone_set('Asia/Jakarta');
    $datetime = date('Y-m-d H:i:s');
    $date = date('Y-m-d');
    $time = date('H:i:s');

    $format_datetime = date("H:i:s / d-M-Y", strtotime($datetime));

    if(isset($_GET["variabel"]) && isset($_GET["value"])){
        $variabel = $_GET["variabel"];
        $value = $_GET["value"];

        //baca doormember dari database
        $cekID = mysqli_query($conn, "SELECT * FROM doormember WHERE id='$value'");
        $row = mysqli_fetch_array($cekID);
        $nama = $row["nama"];
        $nim = $row["nim"];
        $prodi = $row["prodi"];
        $semester = $row["semester"];
        $kelas = $row["kelas"];
        $pm = $row["pm"];
        $jeniskelamin = $row["jeniskelamin"];
        $jabatan = $row["jabatan"];
        $RTF14 = $row["RTF14"];

        //baca data yang dikirim dari device di database
        $result = mysqli_query($conn, "SELECT * FROM receivedata WHERE variabel='$variabel'");
        $row = mysqli_fetch_array($result);
        $cek = $row["value"];
        $mode =  $row["mode"];

        if($variabel == "rfid"){
            //CEK ID
            //Jika ID sudah ada

            // if ($mode == "add"){
            //     if(mysqli_num_rows($cekID > 0)){
            //         if($cek == ''){
            //             // mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ('$variabel', '$value', 'already')");
            //             mysqli_query($conn, "UPDATE receivedata SET value='$value', status='already' WHERE variabel='$variabel'");
            //             echo "#" . $variabel . "|addmember|" . "|already|";
            //         }
            //         // if($cek == '') mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ($variabel', '$value', 'none')");
            //         else {
            //             mysqli_query($conn, "UPDATE receivedata SET value='$value', status='none' WHERE variabel='$variabel'");
            //             echo "#" . $variabel . "|addmember|" . "|none|";
            //         }
            //     }
            // }

            if(mysqli_num_rows($cekID) > 0){
                //Update ID ke db
                // if($cek == '') mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ($variabel, '$value', 'already')");
                // if($cek == '') {
                //     $already = mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ($variabel, '$value', 'already')");
                //     if ($already){
                //         mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ('rfid', '-', '-')");
                //     }
                // }
                if($mode == "add"){
                    mysqli_query($conn, "UPDATE receivedata SET value='$value', status='already' WHERE variabel='$variabel'");
                    echo "#" . $variabel . "|memberalready|" . "|already|";
                }
                // if($cek == ''){
                //     mysqli_query($conn, "UPDATE receivedata SET value='$value', status='already' WHERE variabel='$variabel'");
                //         echo "#" . $variabel . "|memberalready|" . "|already|";
                    // if($mode == "add"){
                        // mysqli_query($conn, "UPDATE receivedata SET value'$value', status='already' WHERE variabel='$variabel'");
                        // echo "#" . $variabel . "|memberalready|" . "|already|";
                    // }
                
                
                // else mysqli_query($conn, "UPDATE receivedata SET value='$value', status='already' WHERE variabel='$variabel'");
                
                // if ($mode == "add"){
                //         if(mysqli_num_rows($cekID > 0)){
                //             if($cek == ''){
                //                 mysqli_query($conn, "UPDATE receivedata SET value='$value', status='already' WHERE variabel='$variabel'");
                //                 echo "#" . $variabel . "|memberalready|" . "|already|";
                //             }
                            // mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ('$variabel', '$value', 'already')");
                            // mysqli_query($conn, "UPDATE receivedata SET value='$value', status='already' WHERE variabel='$variabel'");
                            // echo "#" . $variabel . "|memberalready|" . "|already|";
                            // mysqli_query
                        // }
                        // if($cek == '') mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ($variabel', '$value', 'none')");
                        // else {
                        //     mysqli_query($conn, "UPDATE receivedata SET value='$value', status='none' WHERE variabel='$variabel'");
                        //     echo "#" . $variabel . "|addmember|" . "|none|";
                        // }
                


                else if ($mode == "scan") {
                    //Insert data akses
                    $sql = mysqli_query($conn, "SELECT * FROM authrecord ORDER BY no DESC LIMIT 1");
                    $row = mysqli_fetch_array($sql);
                    $No = $row["no"] + 1;

                    $sql1 = mysqli_query($conn, "SELECT * FROM unauthrecord ORDER BY no DESC LIMIT 1");
                    $row1 = mysqli_fetch_array($sql1);
                    $No1 = $row1["no"] + 1;

                    if ($RTF14 == "Aktif") mysqli_query($conn, "INSERT INTO authrecord (no, id, nama, nim, prodi, semester, kelas, pm, jeniskelamin, jabatan, date, time, ruangan) VALUES ('$No', '$value', '$nama', '$nim', '$prodi', '$semester', '$kelas', '$pm', '$jeniskelamin', '$jabatan', '{$date}', '{$time}', 'RTF1.4')");
                    
                    else                     mysqli_query($conn, "INSERT INTO unauthrecord (no, id, nama, nim, prodi, semester, kelas, pm, jeniskelamin, jabatan, date, time, ruangan) VALUES ('$No1', '$value', '$nama', '$nim', '$prodi', '$semester','$kelas', '$pm', '$jeniskelamin', '$jabatan', '{$date}', '{$time}', 'RTF1.4')");
                    
                    // Insert data tap card
                    $sql = mysqli_query($conn, "SELECT * FROM tapcard ORDER BY no DESC LIMIT 1");
                    $row = mysqli_fetch_array($sql);
                    $No = $row["no"] + 1;
                    $Terdaftar = 'Terdaftar Sebagai: ' . $nama;
                    mysqli_query($conn, "INSERT INTO tapcard (no, id, RTF14, date, time) VALUES ('$No', '$value', '$Terdaftar', '{$date}', '{$time}')");
        
                    //respon to esp
                    if ($RTF14 == "Aktif") echo "#" . $variabel . "|idsudah|" . $nama . "|" . $nim . "|" . $prodi . "|" . $kelas . "|";
                    else                    echo "#" . $variabel . "|idblocked|" . $nama . "|" . $nim . "|" . $prodi . "|" . $kelas . "|";
                    mysqli_query($conn, "UPDATE receivedata SET value='-', status='-', mode='scan' WHERE variabel='rfid'");
                }  
                
                 
                else if ($mode == "enroll") {
                    echo "#" . $variabel . "|enrollsudah|" . $nama . "|" . $nim . "|" . $prodi . "|" . $kelas . "|";
                    mysqli_query($conn, "UPDATE receivedata SET value='-', status='-', mode='enroll' WHERE variabel='rfid'");
                }

            }

            else{
                //Update ID ke db
                // if($cek == '') mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ($variabel', '$value', 'none')");
                // else mysqli_query($conn, "UPDATE receivedata SET value='$value', status='none' WHERE variabel='$variabel'");

                if($mode == "add"){
                    mysqli_query($conn, "UPDATE receivedata SET value='$value', status='none' WHERE variabel='$variabel'");
                    echo "#" . $variabel . "|addmember|" . "|none|";
                }

                if ($mode == "scan") {
                    // //inser unauth record
                    // $sql = mysqli_query($conn, "SELECT * FROM unauthrecord ORDER BY no DESC LIMIT 1");
                    // $row = mysqli_fetch_array($sql);
                    // $No = $row["no"] + 1;
                    // if ($status == "Diblokir") mysqli_query($conn, "INSERT INTO unauthrecord (no, id, nama, nim, prodi, kelas, jeniskelamin, jabatan, nohp, date, time, akses) VALUES ('$No', '$value', '$nama', '$nim', '$prodi', '$kelas', '$jeniskelamin', '$jabatan', '$nohp', '{$date}', '{$time}', 'Diblokir')");
                    // // else mysqli_query($conn, "INSERT INTO unauthrecord (no, id, nama, nim, prodi, kelas, jeniskelamin, jabatan, nohp, date, time, akses) VALUES ('$No', '$value', '$nama', '$nim', '$prodi', '$kelas', '$jeniskelamin', '$jabatan', '$nohp', '{$date}', '{$time}', 'diblokir')");

                    // Insert data tap card
                    $sql = mysqli_query($conn, "SELECT * FROM tapcard ORDER BY no DESC LIMIT 1");
                    $row = mysqli_fetch_array($sql);
                    $No = $row["no"] + 1;
                    mysqli_query($conn, "INSERT INTO tapcard (no, id, ruangan, date, time) VALUES ('$No', '$value', 'Belum Terdaftar', '{$date}', '{$time}')");
        
                    //respon to esp
                    echo "#" . $variabel . "|idbelum|";
                    mysqli_query($conn, "UPDATE receivedata SET value='-', status='-', mode='scan' WHERE variabel='rfid'");
                }
                else if ($mode == "enroll") {
                    echo "#" . $variabel . "|enrollbelum|";
                }
            }
        }

        // else if ($variabel == "alarm") {
        //     Update ID ke db
        //     if ($cek == '') mysqli_query($conn, "INSERT INTO receivedata (variabel, value, status) VALUES ($variabel', $format_datetime, '$value')");
        //     else mysqli_query($conn, "UPDATE receivedata SET value='$format_datetime', status='$value' WHERE variabel='$variabel'");
      
        //     $sql = mysqli_query($conn, "SELECT * FROM dataaksesilegal ORDER BY no DESC LIMIT 1");
        //     $row = mysqli_fetch_array($sql);
        //     $No = $row["no"] + 1;
        //     // Insert data akses
        //     mysqli_query($conn, "INSERT INTO dataaksesilegal (no, date, time) VALUES ('$No', '{$date}', '{$time}')");
        // } 
        
        // else if ($variabel == "control" && $value == "-") {
        //     // Baca status pintu di database
        //     $cek_door = mysqli_query($conn, "SELECT * FROM doorcontrol WHERE no='1'");
        //     $row = mysqli_fetch_array($cek_door);
        //     $Status = $row["ruangan"];

        //     //send to esp
        //     if ($Status == "close") echo "#" . $variabel . "|close|";
        //     else echo "#" . $variabel . "|-|";
        // } 
        
        // else if ($variabel == "control" && $value == "ok") {
        //     // Insert data control
        //     $sql = mysqli_query($conn, "SELECT * FROM datacontrol ORDER BY no DESC LIMIT 1");
        //     $row = mysqli_fetch_array($sql);
        //     $No = $row["no"] + 1;
        //     mysqli_query($conn, "INSERT INTO datacontrol (no, date, time) VALUES ('$No', '{$date}', '{$time}')");
      
        //     // Baca status pintu di database
        //     $cek_door = mysqli_query($conn, "SELECT * FROM doorcontrol WHERE no='1'");
        //     $row = mysqli_fetch_array($cek_door);
        //     $Status = $row["ruangan"];
      
        //     if ($cek_door == '') mysqli_query($conn, "INSERT INTO doorcontrol (no, ruangan) VALUES ('1', '-')");
        //     else mysqli_query($conn, "UPDATE doorcontrol SET ruangan='-' WHERE no='1'");
        // }
    }
?>