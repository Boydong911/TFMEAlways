<?php
    $host = "localhost";
    $user = "id18362223_tfmealways";
    $pass = "ffyy4St@25+hL(||";
    $db   = "id18362223_integrasiakses";

    $conn = mysqli_connect($host, $user, $pass, $db);
    if(!$conn){
        die("Database tidak ada" .mysqli_connect_error());
    }
function query($query){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while( $row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}
?>