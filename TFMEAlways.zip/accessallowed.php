<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Access Allowed | TFME Always</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

    <!--Tabel CSS-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <!--Tabel JS-->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="assets/npm/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/rowreorder/1.2.8/js/dataTables.rowReorder.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
</head>

<style>
    .table{
        margin-top : 25px
    }
    .download button{
    background-color: #2f8d59;
    border: none;
    color: white;
    padding: 10px 15px;
    text-align: center;
    font-size: 15px;
    cursor: pointer;
    transition-property: background;
    box-shadow: 0 2px 7px rgba(0,0,0,0.3);
    margin-top: 15px;
    margin-bottom: 15px;
    margin-left: 15px;
    text-align: center;
    border-radius: 3px;
    font-weight: bold;
    }
    .download button:hover{
    background-color: #0d4627;
    color: white;
    transition: 0.2s ease;
    }
</style>

<body>
    <?php include "menu.php"; ?>
    <?php include "connect.php"?>

    <?php

        $result = mysqli_query($conn, "SELECT * FROM receivedata WHERE variabel='rfid'");
        $row = mysqli_fetch_array($result);
        $cek = $row["value"];

        if ($cek == '') mysqli_query($conn, "UPDATE receivedata SET value='-', status='-', mode='scan' WHERE variabel='rfid'");
        else            mysqli_query($conn, "UPDATE receivedata SET value='-', status='-', mode='scan' WHERE variabel='rfid'");

    ?>
    
    <?php $result = mysqli_query($conn,"SELECT * FROM authrecord")?>



    <h1 style="margin-top : 100px ;margin-bottom : 10px; text-align: center; font-family:Tahoma; font-weight: bold; ">ACCESS ALLOWED</h1>
    <br>
    <div class="download">
        <a href="exportallowed.php"><button class="btn"> DOWNLOAD DATA </button></a>
  <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left: 25px;">
    Download Data Per-Ruangan
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" href="exportallowed_RTF1.4.php">RTF 1.4</a></li>
    <li><a class="dropdown-item" href="exportallowed_CleanR.php">Clean Room</a></li>
    <li><a class="dropdown-item" href="exportallowed_RTF6.1.php">RTF 6.1</a></li>
    <li><a class="dropdown-item" href="exportallowed_RTF6.3.php">RTF 6.3</a></li>
    <li><a class="dropdown-item" href="exportallowed_RTF6.4.php">RTF 6.4</a></li>
    <li><a class="dropdown-item" href="exportallowed_RTFD4.php">RTF D4</a></li>
  </ul>
    </div>
    <div class="container-fluid">
     <table id="example" class="table table-dark table-stripped table-hover" >
	     <thead>
                <tr>
                    <th style="width:10px; text-align: center">No.</th>
                    <th style="text-align:center">ID</th>
                    <th style="text-align:center">Jabatan</th>
                    <th style="text-align:center">NIM</th>
                    <th style="text-align:center">Nama</th>
                    <th style="text-align:center">Kelas</th>
                    <th style="text-align:center">Tanggal</th>
                    <th style="text-align:center">Waktu</th>
                    <th style="text-align:center">Ruangan</th>
                </tr>
            </thead>

            <tbody>
            <?php $no = 1; ?>
            <?php while($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td style="text-align:center"><?= $no; ?></td>
                    <td style="text-align:center"><?= $row["id"]; ?></td>
                    <td style="text-align:center"><?= $row["jabatan"]; ?></td>
                    <td style="text-align:center"><?= $row["nim"]; ?></td>
                    <td style="text-align:center"><?= $row["nama"]; ?></td>
                    <td style="text-align:center"><?= $row["prodi"]; ?>-<?= $row["semester"]; ?>-<?= $row["kelas"]; ?>-<?= $row["pm"]; ?> </td>
                    <td style="text-align:center"><?= $row["date"]; ?></td>
                    <td style="text-align:center"><?= $row["time"]; ?></td>
                    <td style="text-align:center"><?= $row["ruangan"]; ?></td>
                </tr>
                <?php $no++; ?>
                <?php endwhile; ?>
            </tbody>
            <script>
                $(document).ready(function() {
                    $('#example').DataTable();
                } );
            </script>
        </table>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
    </div>
    
</body>
</html>