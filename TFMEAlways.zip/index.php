<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>TFME Always</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

    <style>
      .banner-image{
        background-image: url('images/Polibatam.jpg');
        background-size: cover ;
      }
    </style>
  </head>
  <body>
    <!-- Navbar -->
   <?php include "menu.php"; ?>
    
    <!-- banner Image -->
    <div 
      class="banner-image w-100 vh-100 d-flex justify-content-center align-items-center">
      <div class="content text-center">
        <h1 class="text-white">INTEGRATION OF DATA INTO ROOM</h1>
      </div>
    </div>

    <!-- Main -->
    <div class="container my-5 d-grid gap-5">
      <div class="p-5 border ">
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus consectetur recusandae possimus blanditiis vel, maiores quo consequatur in sunt placeat nobis culpa fugit, voluptas repellat perferendis eius! Veritatis, ea atque.
        </p>
      </div>
      <div class="p-5 border">
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus consectetur recusandae possimus blanditiis vel, maiores quo consequatur in sunt placeat nobis culpa fugit, voluptas repellat perferendis eius! Veritatis, ea atque.
        </p>
      </div>
      <div class="p-5 border">
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus consectetur recusandae possimus blanditiis vel, maiores quo consequatur in sunt placeat nobis culpa fugit, voluptas repellat perferendis eius! Veritatis, ea atque.
        </p>
      </div>
      <div class="p-5 border">
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus consectetur recusandae possimus blanditiis vel, maiores quo consequatur in sunt placeat nobis culpa fugit, voluptas repellat perferendis eius! Veritatis, ea atque.
        </p>
      </div>
      <div class="p-5 border ">
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus consectetur recusandae possimus blanditiis vel, maiores quo consequatur in sunt placeat nobis culpa fugit, voluptas repellat perferendis eius! Veritatis, ea atque.
        </p>
      </div>
      <br>
      <br>
    </div>
    
   
  </body>
</html>