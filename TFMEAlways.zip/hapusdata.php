<?php
    include "connect.php";
    $id = $_GET["id"];
    $delete = mysqli_query($conn, "DELETE FROM doormember WHERE id = $id");
    
    if($delete){
        echo" <script> alert('Member deleted!');document.location.href = 'dataakses.php'</script>";
    }
    else{
        echo" <script> alert('Member delete failed!'); document.location.href = 'dataakses.php'</script>";
    }
    
?>

