<style>
  /* .bgColor{
    background-color: #27614f;
  } */
  .navbar{
    background-color: #228a69;
  }
  .nav-item:hover{
    background-color: #1d7357;
    transition: 0.2s ease;
  }
  .nav-item{
    font-weight: bold
  }
  body{
  background-color: #65C7A8;
	background-size: cover;
	height : 140px;
  }
</style>
<nav class="navbar fixed-top navbar-expand-lg navbar-dark p-md-2"  >
  <div class="container">
    <!-- <h1 href="#" class="navbar-brand" style="font-size:2.8vw; font-family:Tahoma;"><b>TFME</b></h1> -->
    <a class="navbar-brand" href="#">
      <img src="images/logoaseli.png" alt="" width="80" height="54">
    </a>
    
      <button
        type="button"
        class="navbar-toggler navbar-dark"
        data-bs-target="#navbarNav"
        data-bs-toggle="collapse"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle Navbar"    
       >
        <span class="navbar-toggler-icon"></span>
      </button>

        <div class="collapse navbar-collapse" id="navbarNav">
          <div class="mx-auto"></div>
          <ul class="navbar-nav ">
            <li class="nav-item px-3 py-3">
              <a href="index.php" class="nav-link active">HOME</a>
            </li>
            <li class="nav-item px-3 py-3">
              <a href="dataakses.php" class="nav-link active">Member</a>
            </li>
            <li class="nav-item px-3 py-3">
              <a href="accessallowed.php" class="nav-link active">Access Allowed</a>
            </li>
            <li class="nav-item px-3 py-3">
              <a href="accessunallowed.php" class="nav-link active">Access Unallowed</a>
            </li>
          </ul>
    </div>
  </div>
</nav>

<script src="js/bootstrap.bundle.min.js"></script>

<!-- <script>
  var nav = document.querySelector('nav');
    window.addEventListener('scroll',function(){
    if(window.pageYOffset > 100){
      nav.classList.add('bgColor','shadow');
    }
    else{
      nav.classList.remove('bgColor','shadow');
    }
  });
</script> -->