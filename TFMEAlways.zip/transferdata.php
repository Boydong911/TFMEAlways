<?php
include "connect.php"
?>

<?php
    if(isset($_GET["variabel"])){
        $variable = $_GET["variabel"];

        $result = mysqli_query($conn, "SELECT * FROM receivedata WHERE variabel='$variabel'");
        $row = mysqli_fetch_array($result);
        $mode = $row["mode"];
        $value = $row["value"];

        if($variabel == "rfid" && $mode == "scan"){
            $cekID = mysqli_query($conn, "SELECT * FROM doormember WHERE id='$value'");
            $row = mysqli_fetch_array($cekID);
            $nama = $row["nama"];
            $nim = $row["nim"];
            $prodi = $row["prodi"];
            $kelas = $row["kelas"];
            // $organisasi = $row["organisasi"];

            if (mysqli_num_rows($cekID) > 0) echo "#" . $variabel . "|idsudah|" . $nama . "|" . $nim . "|" . $prodi . "|" . $kelas . "|";
            else                             echo "#" . $variabel . "|idbelum|" . $nama . "|" . $nim . "|" . $prodi . "|" . $kelas . "|";
        }
    }
?>