<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Edit Member | TFME Always</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            setInterval(function(){
                    $("#norfid").load('nokartu.php') 
                }, 1000);  //pembacaan file nokartu.php, tiap 1 detik = 1000
            });
    </script>
</head>

<style>
    .member-add-button{
    background-color: rgb(53, 163, 197);
    border: none;
    color: white;
    padding: 10px 15px;
    text-align: center;
    font-size: 15px;
    cursor: pointer;
    transition-property: background;
    box-shadow: 0 2px 7px rgba(0,0,0,0.3);
    margin-top: 15px;
    margin-bottom: 15px;
    margin-left: 15px;
    text-align: center;
    border-radius: 3px;
    font-weight: bold;
    }
    .member-add-button:hover{
    background-color: rgb(11, 69, 87);
    color: white;
    transition: 0.2s ease;
    }
    .member-cancel-button {
    background-color: rgb(255, 61, 61);
    border: none;
    color: white;
    padding: 10px 15px;
    text-align: center;
    font-size: 15px;
    cursor: pointer;
    transition-property: background;
    box-shadow: 0 2px 7px rgba(0,0,0,0.3);
    margin-top: 15px;
    margin-bottom: 15px;
    margin-left: 15px;
    text-align: center;
    border-radius: 3px;
    font-weight: bold;
    }
    .member-cancel-button:hover {
    background-color: rgb(184, 8, 8);
    color: white;
    transition: 0.2s ease;
    }
    .done-button {
    background-color: rgb(255, 61, 61);
    border: none;
    color: white;
    padding: 10px 15px;
    text-align: center;
    font-size: 15px;
    cursor: pointer;
    transition-property: background;
    box-shadow: 0 2px 7px rgba(0,0,0,0.3);
    margin-top: 15px;
    margin-bottom: 15px;
    margin-left: 15px;
    text-align: center;
    border-radius: 3px;
    font-weight: bold;
    }
    .done-button:hover {
    background-color: rgb(184, 8, 8);
    color: white;
    transition: 0.2s ease;
    }
    .current-id{
    background-color: rgb(53, 163, 197);
    border: none;
    color: white;
    padding: 10px 15px;
    text-align: center;
    font-size: 15px;
    cursor: pointer;
    transition-property: background;
    box-shadow: 0 2px 7px rgba(0,0,0,0.3);
    margin-top: 15px;
    margin-bottom: 15px;
    margin-left: 15px;
    text-align: center;
    border-radius: 3px;
    font-weight: bold;
    }
    .current-id:hover{
    background-color: rgb(11, 69, 87);
    color: white;
    transition: 0.2s ease;
    }
</style>

<body>
    <?php include "menu.php"; ?>
    <?php include "connect.php" ?>

    <?php
        // Get ID from database
        $sql = mysqli_query($conn, "SELECT * FROM receivedata WHERE variabel='rfid'");
        $row = mysqli_fetch_array($sql);
        $ID = $row["value"];
    ?>

    <?php
        // // Update database
        if ($ID == "-") mysqli_query($conn, "UPDATE receivedata SET value='-', status='-', mode='add' WHERE variabel='rfid'");
    ?>

    <h1 style="margin-top : 100px ;margin-bottom : 10px; text-align: center; font-family:Tahoma; font-weight: bold; ">EDIT MEMBER</h1>
    <?php 
        if(isset($_GET['no'])){
        $no = $_GET['no'];
        $sql = mysqli_query($conn, "SELECT * FROM doormember WHERE no = $no");
        $data = mysqli_fetch_array($sql);
                
        $id = $data["id"];
        $nama = $data["nama"];
        $nim = $data["nim"];
        $prodi = $data["prodi"];
        $semester = $data["semester"];
        $kelas = $data["kelas"];
        $pm = $data["pm"];
        $jeniskelamin = $data["jeniskelamin"];
        $jabatan = $data["jabatan"];
        $RTF14 = $data["RTF14"];
        $CR = $data["CR"];
        $RTF61 = $data["RTF61"];
        $RTF63 = $data["RTF63"];
        $RTF64 = $data["RTF64"];
        $RTFD4 = $data["RTFD4"];
            
        ?>
    <form action="" method="post">
        <input class="current-id" style="margin-left : 20px; font-weight: bold; font-family:Tahoma; color:black; text-align:center;"type="text" name="id" id='id' autocomplete="off" value="Current ID: <?php echo $id; ?>" readonly>
        <br>
        <!-- <div id="norfid"></div> -->
        <div class="form" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <span class="content-name" >ID</span>
            <br>
            <input style="width: 400px" type="number" name="id" id='id' autocomplete="off" value="<?php echo $id; ?>" required readonly>
            <label for="id" class="form-label"></label>
        </div>
        <br>
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <select name="jabatan" id="jabatan" class="form-option" required>
                <option value="<?php echo $jabatan; ?>"><?php echo $jabatan; ?></option>
                <option value="Mahasiswa">Mahasiswa</option>
                <option value="Dosen">Dosen</option>
            </select>
        </div>
        <br>
        <div class="form" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <span class="content-name" >Nama</span>
            <br>
            <input style="width: 400px" type="text" name="nama" id='nama' autocomplete="off" value="<?php echo $nama; ?>" required>
            <label for="nama" class="form-label"></label>
        </div>
        <br> 
        <div class="form" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <span class="content-name">NIM/NID</span>
            <br>
            <input style="width: 400px" placeholder="NIM/NID" type="number" name="nim" id='nim' autocomplete="off" value="<?php echo $nim; ?>"required >
            <label for="nim" class="form-label"></label>
        </div>

        <br>

        <!-- <div class="form-select"> -->
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <select type="text" name="prodi" id="prodi" class="form-option" required>
                <option value="<?php echo $prodi; ?>" style="text-align: center"><?php echo $prodi; ?></option>

                <option value="EL">EL (Teknik Elektronika)</option>
                <option value="MK">MK (Teknik Mekatronika)</option>
                <option value="EM">EM (Teknik Elektronika Manufaktur)</option>
                <option value="RB">RB (Teknik Robotika)</option>
                <option value="INS">INS (Teknik Instrumentasi)</option>
                <option value="RPE">RPE (Teknik Rekayasa Pembangkit Energi)</option>
                <option value="IF">IF (Teknik Informatika)</option>
                <option value="MJ">MJ (Teknik Multimedia dan Jaringan)</option>
                <option value="GEO">GEO (Teknik Geomatika)</option>
                <option value="RKS">RKS (Rekayasa Keamanan Siber)</option>
                <option value="Animasi">(Animasi)</option>
                <option value="Mesin">(Teknik Mesin)</option>
                <option value="Kapal">(Teknik Perencanaan Konstruksi Kapal)</option>
                <option value="TPPU">(Teknik Perawatan Pesawat Udara)</option>
                <option value="AK">AK (Akuntansi)</option>
                <option value="AM">AM (Akuntansi Manajerial)</option>
                <option value="AB">AB (Administrasi Bisnis Terapan)</option>
                <option value="LPI">LPI (Logistik Perdagangan Internasional)</option>
                <option value="ABI">ABI (Business Administration (International Class))</option>
            </select>
        </div>
        <br>
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <select name="semester" id="semester" class="form-option" required>
                <option value="<?php echo $semester; ?>"><?php echo $semester; ?></option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
            </select>
        </div>
        <br>
        <!-- <div class="form"> -->
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <select name="kelas" id="kelas" class="form-option" required>
                <option value="<?php echo $kelas; ?>"><?php echo $kelas; ?></option>
                <option value="A">A</option>
                <option value="B">B</option>
            </select>
        </div>
        <br>
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <select name="pm" id="pm" class="form-option" required>
                <option value="<?php echo $pm; ?>"><?php echo $pm; ?></option>
                <option value="Pagi">Pagi</option>
                <option value="Malam">Malam</option>
            </select>
        </div>
        <br>

        <!-- <div class="form-select"> -->
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            <select name="jeniskelamin" id="jeniskelamin" class="form-option" required>
                <option value="<?php echo $jeniskelamin; ?>"><?php echo $jeniskelamin; ?></option>
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>
        </div>
        <br>

        <!-- <div class="form-select"> -->


        <!-- <div class="form-select"> -->
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
        <span class="content-name">RTF1.4</span>
            <br>
            <select name="RTF14" id="RTF14" class="form-option" required>
                <option value="<?php echo $RTF14; ?>"><?php echo $RTF14; ?></option>
                <option value="Aktif">Aktif</option>
                <option value="Diblokir">Diblokir</option>
            </select>
        </div>
        <br>
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
        <span class="content-name">Clean Room</span>
            <br>
            <select name="CR" id="CR" class="form-option" required>
                <option value="<?php echo $CR; ?>"><?php echo $CR; ?></option>
                <option value="Aktif">Aktif</option>
                <option value="Diblokir">Diblokir</option>
            </select>
        </div>
        <br>
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
        <span class="content-name">RTF 6.1</span>
            <br>
            <select name="RTF61" id="RTF61" class="form-option" required>
                <option value="<?php echo $RTF61; ?>"><?php echo $RTF61; ?></option>
                <option value="Aktif">Aktif</option>
                <option value="Diblokir">Diblokir</option>
            </select>
        </div>
        <br>
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
        <span class="content-name">RTF 6.3</span>
            <br>
            <select name="RTF63" id="RTF63" class="form-option" required>
                <option value="<?php echo $RTF63; ?>"><?php echo $RTF63; ?></option>
                <option value="Aktif">Aktif</option>
                <option value="Diblokir">Diblokir</option>
            </select>
        </div>
        <br>
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
        <span class="content-name">RTF6.4</span>
            <br>
            <select name="RTF64" id="RTF64" class="form-option" required>
                <option value="<?php echo $RTF64; ?>"><?php echo $RTF64; ?></option>
                <option value="Aktif">Aktif</option>
                <option value="Diblokir">Diblokir</option>
            </select>
        </div>
        <br>
        <div class="form-option" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
        <span class="content-name">RTF D4</span>
            <br>
            <select name="RTFD4" id="RTFD4" class="form-option" required>
                <option value="<?php echo $RTFD4; ?>"><?php echo $RTFD4; ?></option>
                <option value="Aktif">Aktif</option>
                <option value="Diblokir">Diblokir</option>
            </select>
        </div>
        <br>
        <br>

        <div class="button">
            <button class="member-add-button" type="submit" name="submit" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            Edit Data</button>
            <button class="member-cancel-button" type="button" onclick="location='dataakses.php'" style="margin-left : 20px; font-weight: bold; font-family:Tahoma;">
            Cancel</button>
        </div>

    </form>

    <?php
        if (isset ($_POST["submit"])){
            $id = ($_POST["id"]);
            $jabatan = htmlspecialchars($_POST["jabatan"]);
            $nama = htmlspecialchars($_POST["nama"]);
            $nim = htmlspecialchars($_POST["nim"]);
            $prodi = htmlspecialchars($_POST["prodi"]);
            $semester = htmlspecialchars($_POST["semester"]);
            $kelas = htmlspecialchars($_POST["kelas"]);
            $pm = htmlspecialchars($_POST["pm"]);
            $jeniskelamin = htmlspecialchars($_POST["jeniskelamin"]);
            $RTF14 = htmlspecialchars($_POST["RTF14"]);
            $CR = htmlspecialchars($_POST["CR"]);
            $RTF61 = htmlspecialchars($_POST["RTF61"]);
            $RTF63 = htmlspecialchars($_POST["RTF63"]);
            $RTF64 = htmlspecialchars($_POST["RTF64"]);
            $RTFD4 = htmlspecialchars($_POST["RTFD4"]);

            $sql = mysqli_query($conn, "UPDATE doormember SET id='$id', jabatan='$jabatan', nama='$nama', nim='$nim', 
            prodi='$prodi', semester='$semester', kelas='$kelas', pm='$pm', jeniskelamin='$jeniskelamin', 
            RTF14='$RTF14', CR='$CR', RTF61='$RTF61', RTF63='$RTF63', RTF64='$RTF64', RTFD4='$RTFD4' WHERE no='$no'");

            if($sql){
                echo" <script> alert('Member successfully edited!');
                document.location.href = 'dataakses.php'
                </script>
                ";
            }
            else{
                echo" <script> alert('Member edit failed!');
                document.location.href = 'dataakses.php'
                </script>
                ";
            }
        }
    }
    ?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
</body>
</html>